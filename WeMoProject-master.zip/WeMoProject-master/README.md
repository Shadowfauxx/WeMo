# WeMoProject
Throw away project for beginners
For Joe and Nick, 
  We are going to use this git to house our project. This is also a public project so anyone can view it.
  Using git since it is easier to share code like this. Blah blah blah.
